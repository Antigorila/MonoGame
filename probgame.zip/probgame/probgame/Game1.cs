﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using MonoGame.Extended;
using MonoGame.Extended.Animations;
using static System.Formats.Asn1.AsnWriter;

namespace probgame
{
    abstract class Entity
    {
        public int Level { get; set; }
        public double MaxHP { get; set; }
        public double CurrentHP { get; set; }
        public double AttackPoint { get; set; }
        public Texture2D Texture { get; set; }
        public double DefensePoint { get; set; }
        public int[] Position = new int[2];
        public bool Dead = false;
        public bool HaveKey = false;
        public bool readyToFight;
        public void checkIfDead()
        {
            if (CurrentHP <= 0)
            {
                Die();
            }
        }
        public virtual void Die()
        {
            this.Dead = true;
        }
        //private Random rng = new Random();
        //public int RollDice()
        //{
        //    return rng.Next(1, 7);
        //}
    }
    class Hero : Entity
    {
        public bool DefeatedBoss = false;
        public Hero()
        {
            MaxHP = 20 + 3 * Szint.RollDice();
            CurrentHP = MaxHP;
            DefensePoint = 2 * Szint.RollDice();
            AttackPoint = 5 + Szint.RollDice();
            Level = 1;
            readyToFight = true;
            HaveKey = false;
        }
        public bool CanGoNextLevel()
        {
            if (HaveKey && DefeatedBoss)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void HeroOnNewMap()
        {
            int diceNumber = Szint.RollDice();
            if (diceNumber == 10)
            {
                this.CurrentHP = this.MaxHP;
            }
            else if (diceNumber >= 6)
            {
                if ((this.CurrentHP + (this.MaxHP / 3)) > MaxHP)
                {
                    CurrentHP = MaxHP;
                }
                else
                {
                    this.CurrentHP +=this.MaxHP / 3;
                }
            }
            else
            {
                if ((this.CurrentHP + Convert.ToInt32(this.MaxHP * 0.10)) > MaxHP)
                {
                    CurrentHP = MaxHP;
                }
                else
                {
                    this.CurrentHP +=Convert.ToInt32(this.MaxHP * 0.10);
                }
            }
        }
        public void LevelUp()
        {
            Level++;
            int rolledHP = Szint.RollDice();
            MaxHP += rolledHP;
            CurrentHP += rolledHP;
            DefensePoint += Szint.RollDice();
            AttackPoint += Szint.RollDice();
        }
        public override void Die()
        {
            System.Environment.Exit(0);
            
        }
    }
    class Monster : Entity
    {
        public Monster(int Level, Texture2D texture)
        {
            Texture = texture;
            int diceNumber = Szint.RollDice();
            if (diceNumber == 10)
            {
                this.Level = Level + 2;
            }
            else if (diceNumber >= 6)
            {
                this.Level = Level + 1;
            }
            else
            {
                this.Level = Level;
            }
            readyToFight = true;
            HaveKey = false;
            SetStats(this.Level);
            Texture = texture;
        }
        private void SetStats(int Level)
        {
            MaxHP = 2 * Level * Szint.RollDice();
            CurrentHP = MaxHP;
            DefensePoint = (double)Level / 2 * Szint.RollDice();
            AttackPoint = Level * Szint.RollDice();
        }
        public override void Die()
        {
            this.Dead = true;
            if (this.HaveKey == true)
            {
                Szint.currentHero.HaveKey = true;
            }
            Szint.currentHero.LevelUp();
        }
    }
    class Boss : Entity
    {
        public Boss(Texture2D texture, int level)
        {
            this.Texture = texture;
            int diceNumber = Szint.RollDice();
            if (diceNumber == 10)
            {
                this.Level = level + 2;
            }
            else if (diceNumber >= 6)
            {
                this.Level = level + 1;
            }
            else
            {
                this.Level = level;
            }
            readyToFight = true;
            HaveKey = false;
            SetStats(this.Level);
        }
        private void SetStats(int Level)
        {
            MaxHP = 2 * Level * Szint.RollDice() + Szint.RollDice();
            CurrentHP = MaxHP;
            DefensePoint = (double)Level / 2 * Szint.RollDice() + (double)Szint.RollDice() / 2;
            AttackPoint = Level * Szint.RollDice() + Level;
        }
        public override void Die()
        {
            this.Dead = true;

            Szint.currentHero.DefeatedBoss = true;
            Szint.currentHero.LevelUp();

        }
    }
    class Szint
    {
        private static readonly RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider();
        public static int number = 0;
        public static Hero currentHero = new Hero();
        public static List<Entity> MonsterList = new List<Entity>();
        public static int RollDice()
        {
            byte[] randomNumber = new byte[4];
            rngCsp.GetBytes(randomNumber);

            int generatedValue = BitConverter.ToInt32(randomNumber, 0);

            return Math.Abs(generatedValue % 6) + 1;
        }
        public static void fight(Entity attacker, Entity defender)
        {

            while (attacker.Dead == false && defender.Dead == false)
                if (attacker.readyToFight == true)
                {
                    double attackdamage = attacker.AttackPoint + 2 * RollDice();
                    Console.WriteLine($"{attacker} is attacking with {attackdamage} sp");

                    if (defender.DefensePoint < attackdamage)
                    {
                        double totaldamage = attackdamage - defender.DefensePoint;
                        defender.CurrentHP -= totaldamage;
                        Console.WriteLine($"Damage: {totaldamage}");
                        Console.WriteLine($"Defenders hp: {defender.CurrentHP}");
                        defender.checkIfDead();
                        if (defender.Dead == false)
                        {
                            var csere = attacker;
                            attacker = defender;
                            defender = csere;
                        }
                    }
                    else
                    {
                        var csere = attacker;
                        attacker = defender;
                        defender = csere;
                        Console.WriteLine($"Defender has more defense point");
                    }

                }
            Console.WriteLine($"The winner is {attacker}");

        }
        public static void clean()
        {
            for (int i = 0; i < MonsterList.Count; i++)
            {
                if (MonsterList[i].Dead == true)
                {
                    MonsterList.RemoveAt(i);
                }
            }
        }
    }
    class Controll
    {
        public static int[,] maze;
        public static int tileSize = 32;
        public static int rows = 15;
        public static int cols = 15;

        public static void FindStartPosition(Entity entity)
        {
            int row = new Random().Next(0, rows);
            int col = new Random().Next(0, cols);

            if (maze[row, col] == 0)
            {
                entity.Position[0] = row;
                entity.Position[1] = col;
            }
            else
            {
                FindStartPosition(entity);
            }
        }
        public static void Move(Entity entity, int rowOffset, int colOffset)
        {
            int targetRow = entity.Position[0] + rowOffset;
            int targetCol = entity.Position[1] + colOffset;

            if (targetRow >= 0 && targetRow < rows && targetCol >= 0 && targetCol < cols)
            {
                if (maze[targetRow, targetCol] == 0)
                {
                    entity.Position[0] = targetRow;
                    entity.Position[1] = targetCol;
                }
            }
        }
    }
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont gameFont;
        Texture2D wallTexture;
        Texture2D floorTexture;
        Texture2D backgroundTexture;
        public Texture2D hosTexture;
        Texture2D bossTexture;
        List<Texture2D> monsterTexturesList = new List<Texture2D>();
        Hero player = Szint.currentHero;
        float timer;
        int herolap = 0;
        public int steps = 0;
        bool[,] visible = new bool[Controll.rows, Controll.cols];
        int viewRange = 1;
        Color fogColor = Color.Black;
        //AnimationFactory _animationFactory;
        //AnimatedSprite _animatedSprite;
        KeyboardState currentKeyboardState, previousKeyboardState;
        public Game1()
        {

            timer = 0f;
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = (int)(Controll.tileSize * 1.25f * Controll.cols);
            graphics.PreferredBackBufferHeight = (int)(Controll.tileSize * 1.5f * Controll.rows);
            graphics.IsFullScreen = true;
            Content.RootDirectory = "Content";
    }

        static void GiveKey(List<Entity> MonsterList)
        {
            Random rng = new Random();
            int index = rng.Next(0, MonsterList.Count());
            if (MonsterList[index].GetType().Name == "Monster")
            {
                MonsterList[rng.Next(0, MonsterList.Count())].HaveKey = true;
            }
            else
            {
                GiveKey(MonsterList);
            } 
        }
        protected override void Initialize()
        {
            base.Initialize();
            BeginnewGame();
        }
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            wallTexture = Content.Load<Texture2D>("fal");
            floorTexture = Content.Load<Texture2D>("padlo");
            backgroundTexture = Content.Load<Texture2D>("background");
            gameFont = Content.Load<SpriteFont>("galleryFont");
            hosTexture = Content.Load<Texture2D>("hos");
            bossTexture = Content.Load<Texture2D>("boss");
            for (int i = 0; i < 6; i++)
            {
                monsterTexturesList.Add(Content.Load<Texture2D>($"monster{i + 1}"));
            }
            ////Betöltjük a GIF fájlt egy animációként
            //_animationFactory = new AnimationFactory(Content.Load<Texture2D>("dance"));

            ////Létrehozunk egy animált sprite-ot az animációval
            //_animatedSprite = new AnimatedSprite(_animationFactory, "default");
        }
        protected override void Update(GameTime gameTime)
        {
            currentKeyboardState = Keyboard.GetState();
            Szint.clean();
            if (currentKeyboardState.IsKeyDown(Keys.Escape))
            {
                Exit();
            }
                    for (int i = player.Position[0] - viewRange; i <= player.Position[0] + viewRange; i++)
        {
            for (int j = player.Position[1] - viewRange; j <= player.Position[1] + viewRange; j++)
            {
                if (i >= 0 && i < Controll.rows && j >= 0 && j < Controll.cols)
                {
                    visible[i, j] = true;
                }
            }
        }
            #region Controlls

            if (currentKeyboardState.IsKeyDown(Keys.W) && !previousKeyboardState.IsKeyDown(Keys.W) || currentKeyboardState.IsKeyDown(Keys.Up) && !previousKeyboardState.IsKeyDown(Keys.Up))
            {
                Controll.Move(player, -1, 0);
                HeroDueld();
                HeroMoveTwice();
            }
            if (currentKeyboardState.IsKeyDown(Keys.LeftControl) && currentKeyboardState.IsKeyDown(Keys.K) && !previousKeyboardState.IsKeyDown(Keys.K))
            {
                Szint.fight(player, Szint.MonsterList[0]);
            }
            if (currentKeyboardState.IsKeyDown(Keys.LeftControl) && currentKeyboardState.IsKeyDown(Keys.L) && !previousKeyboardState.IsKeyDown(Keys.L))
            {
                player.DefeatedBoss = true;
                player.HaveKey = true;
            }
            if (currentKeyboardState.IsKeyDown(Keys.S) && !previousKeyboardState.IsKeyDown(Keys.S) || currentKeyboardState.IsKeyDown(Keys.Down) && !previousKeyboardState.IsKeyDown(Keys.Down))
            {
                Controll.Move(player, 1, 0);
                HeroDueld();
                HeroMoveTwice();
            }
            if (currentKeyboardState.IsKeyDown(Keys.A) && !previousKeyboardState.IsKeyDown(Keys.A) || currentKeyboardState.IsKeyDown(Keys.Left) && !previousKeyboardState.IsKeyDown(Keys.Left))
            {
                Controll.Move(player, 0, -1);
                HeroDueld();
                HeroMoveTwice();
            }
            if (currentKeyboardState.IsKeyDown(Keys.D) && !previousKeyboardState.IsKeyDown(Keys.D) || currentKeyboardState.IsKeyDown(Keys.Right) && !previousKeyboardState.IsKeyDown(Keys.Right))
            {
                Controll.Move(player, 0, 1);
                HeroDueld();
                HeroMoveTwice();
            }
            if (currentKeyboardState.IsKeyDown(Keys.W) || currentKeyboardState.IsKeyDown(Keys.S) || currentKeyboardState.IsKeyDown(Keys.A) || currentKeyboardState.IsKeyDown(Keys.D) || currentKeyboardState.IsKeyDown(Keys.Up) || currentKeyboardState.IsKeyDown(Keys.Down) || currentKeyboardState.IsKeyDown(Keys.Left) || currentKeyboardState.IsKeyDown(Keys.Right))
            {
                timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
            else
            {
                timer = 0;
            }
            if (timer >= 0.2)
            {
                if (currentKeyboardState.IsKeyDown(Keys.W) || currentKeyboardState.IsKeyDown(Keys.Up))
                {
                    Controll.Move(player, -1, 0);
                    HeroDueld();
                    HeroMoveTwice();
                }
                if (currentKeyboardState.IsKeyDown(Keys.S) || currentKeyboardState.IsKeyDown(Keys.Down))
                {
                    Controll.Move(player, 1, 0);
                    HeroDueld();
                    HeroMoveTwice();
                }
                if (currentKeyboardState.IsKeyDown(Keys.A) || currentKeyboardState.IsKeyDown(Keys.Left))
                {
                    Controll.Move(player, 0, -1);
                    HeroDueld();
                    HeroMoveTwice();
                }
                if (currentKeyboardState.IsKeyDown(Keys.D) || currentKeyboardState.IsKeyDown(Keys.Right))
                {
                    Controll.Move(player, 0, 1);
                    HeroDueld();
                    HeroMoveTwice();
                }
                timer = 0;
            }
            previousKeyboardState = currentKeyboardState;
            #endregion

            if (player.CanGoNextLevel())
            {
                BeginnewGame();
            }
        }
        #region Maze Methoods
        void ResetFog()
        {
            for (int i = 0; i < Controll.rows; i++)
            {
                for (int j = 0; j < Controll.cols; j++)
                {
                    visible[i, j] = false;
                }
            }
        }

        public void BeginnewGame()
        {
            player.HaveKey = false;
            player.DefeatedBoss = false;

            Szint.MonsterList.Clear();
            player.HeroOnNewMap();
            Szint.number++;
            Random rng = new Random();
            for (int i = 0; i < rng.Next(3, 7); i++)
            {
                Monster _moster = new Monster(Szint.number, monsterTexturesList[i]);
                Szint.MonsterList.Add(_moster);
            }
            GiveKey(Szint.MonsterList);
            Boss boss = new Boss(bossTexture, Szint.number);
            Szint.MonsterList.Add(boss);

            Controll.maze = new int[Controll.rows, Controll.cols];
            player.Position = new int[2];
            GenerateMaze(0, 0, Controll.rows - 1, Controll.cols - 1);

            // Frissítjük az animált sprite-ot
           // _animatedSprite.Update(gameTime);

            Controll.FindStartPosition(player);
            ResetFog();
            CheckDistance();
        }
        void GenerateMaze(int top, int left, int bottom, int right)
        {
            if (bottom - top < 2 || right - left < 2)
            {
                return;
            }
            bool vertical = new Random().Next(2) == 0;
            int wall;
            int hole;
            if (vertical)
            {
                wall = new Random().Next(left + 1, right);
                hole = new Random().Next(top + 1, bottom);
                for (int i = top; i <= bottom; i++)
                {
                    if (i != hole)
                    {
                        Controll.maze[i, wall] = 1;
                    }
                }
                if (top > 0 && Controll.maze[top - 1, wall] == 0)
                {
                    Controll.maze[top, wall] = 0;
                }
                if (bottom < Controll.rows - 1 && Controll.maze[bottom + 1, wall] == 0)
                {
                    Controll.maze[bottom, wall] = 0;
                }

                GenerateMaze(top, left, bottom, wall - 1);
                GenerateMaze(top, wall + 1, bottom, right);
            }
            else
            {
                wall = new Random().Next(top + 1, bottom);
                hole = new Random().Next(left + 1, right);

                for (int j = left; j <= right; j++)
                {
                    if (j != hole)
                    {
                        Controll.maze[wall, j] = 1;
                    }
                }
                if (left > 0 && Controll.maze[wall, left - 1] == 0)
                {
                    Controll.maze[wall, left] = 0;
                }
                if (right < Controll.cols - 1 && Controll.maze[wall, right + 1] == 0)
                {
                    Controll.maze[wall, right] = 0;
                }
                GenerateMaze(top, left, wall - 1, right);
                GenerateMaze(wall + 1, left, bottom, right);
            }
        }
        #endregion
        public void HeroMoveTwice()
        {
            if (herolap == 1)
            {
                MoveMonsters();
                herolap = 0;
            }
            else
            {
                herolap++;
            }
        }
        public void MoveMonsters()
        {
            Random rng = new Random();
            foreach (Entity monster in Szint.MonsterList)
            {
                int direction = rng.Next(0, 4);
                switch (direction)
                {
                    case 0:
                        Controll.Move(monster, -1, 0);
                        break;
                    case 1:
                        Controll.Move(monster, 0, 1);
                        break;
                    case 2:
                        Controll.Move(monster, 1, 0);
                        break;
                    case 3:
                        Controll.Move(monster, 0, -1);
                        break;
                }
                if (monster.Position[0] == player.Position[0] && monster.Position[1] == player.Position[1])
                {
                    Szint.fight(monster, player);


                }
            }
        }

        public void CheckDistance()
        {
            bool valid = true;
            for (int i = 0; i < Szint.MonsterList.Count; i++)
            {
                for (int j = i + 1; j < Szint.MonsterList.Count; j++)
                {
                    int distance = Math.Abs(Szint.MonsterList[i].Position[0] - Szint.MonsterList[j].Position[0]) + Math.Abs(Szint.MonsterList[i].Position[1] - Szint.MonsterList[j].Position[1]);
                    if (distance < 5)
                    {
                        valid = false;
                        break;
                    }
                }
                int distanceToPlayer = Math.Abs(Szint.MonsterList[i].Position[0] - player.Position[0]) + Math.Abs(Szint.MonsterList[i].Position[1] - player.Position[1]);
                if (distanceToPlayer < 5)
                {
                    valid = false;
                    break;
                }
            }
            if (!valid)
            {
                foreach (Entity monster in Szint.MonsterList)
                {
                    Controll.FindStartPosition(monster);
                }
                CheckDistance();
            }
        }

        public void HeroDueld()
        {
            for (int i = 0; i < Szint.MonsterList.Count; i++)
            {
                if (Szint.MonsterList[i].Position[0] == player.Position[0] && Szint.MonsterList[i].Position[1] == player.Position[1])
                {
                    Szint.fight(player, Szint.MonsterList[i]);
                    
                    break;
                }
            }
        }
        protected override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(backgroundTexture, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);

            int mazeWidth = (int)(Controll.tileSize * 1.25f * Controll.cols);
            int mazeHeight = (int)(Controll.tileSize * 1.5f * Controll.rows);
            int mazeX = (GraphicsDevice.Viewport.Width - mazeWidth) / 2;
            int mazeY = (GraphicsDevice.Viewport.Height - mazeHeight) / 2;

            for (int i = 0; i < Controll.rows; i++)
            {
                for (int j = 0; j < Controll.cols; j++)
                {
                    int x = (int)(j * Controll.tileSize * 1.25f) + mazeX;
                    int y = (int)(i * Controll.tileSize * 1.5f) + mazeY;
                    if (Controll.maze[i, j] != 1)
                    {
                        int wallWidth = (int)(Controll.tileSize * 1.25f);
                        int wallHeight = (int)(Controll.tileSize * 2f);
                        int wallX = x;
                        int wallY = (int)(y + (Controll.tileSize * 1.25f - wallHeight) / 2);
                        if (visible[i, j])
                        {
                            spriteBatch.Draw(floorTexture, new Rectangle(wallX, wallY, wallWidth, wallHeight), Color.White);
                        }
                        else
                        {
                            spriteBatch.Draw(floorTexture, new Rectangle(wallX, wallY, wallWidth, wallHeight), fogColor);
                        }
                    }
                }
            }

            spriteBatch.Draw(hosTexture, new Rectangle((int)(player.Position[1] * Controll.tileSize * 1.25f) + mazeX, (int)(player.Position[0] * Controll.tileSize * 1.5f) + mazeY, (int)(Controll.tileSize * 1.25f), (int)(Controll.tileSize * 1.5f)), Color.White);

            foreach (Entity monster in Szint.MonsterList)
            {
                int i = monster.Position[0];
                int j = monster.Position[1];

                if (visible[i, j])
                {
                    if (monster.GetType().Name == "Boss")
                    {
                        spriteBatch.Draw(bossTexture, new Rectangle((int)(j * Controll.tileSize * 1.25f) + mazeX, (int)(i * Controll.tileSize * 1.5f) + mazeY, (int)(Controll.tileSize * 1.25f), (int)(Controll.tileSize * 1.5f)), Color.White);
                    }
                    else
                    {
                        spriteBatch.Draw(monster.Texture, new Rectangle((int)(j * Controll.tileSize * 1.25f) + mazeX, (int)(i * Controll.tileSize * 1.5f) + mazeY, (int)(Controll.tileSize * 1.25f), (int)(Controll.tileSize * 1.5f)), Color.White);
                    }
                }
                else
                {
                    spriteBatch.Draw(monster.Texture, new Rectangle((int)(j * Controll.tileSize * 1.25f) + mazeX, (int)(i * Controll.tileSize * 1.5f) + mazeY, (int)(Controll.tileSize * 1.25f), (int)(Controll.tileSize * 1.5f)), fogColor);
                }
            }

            for (int i = 0; i < Controll.rows; i++)
            {
                for (int j = 0; j < Controll.cols; j++)
                {
                    int x = (int)(j * Controll.tileSize * 1.25f) + mazeX;
                    int y = (int)(i * Controll.tileSize * 1.5f) + mazeY;
                    if (Controll.maze[i, j] == 1)
                    {
                        int wallWidth = (int)(Controll.tileSize * 1.25f);
                        int wallHeight = (int)(Controll.tileSize * 2f);
                        int wallX = x;
                        int wallY = (int)(y + (Controll.tileSize * 1.25f - wallHeight) / 2);
                        if (visible[i, j])
                        {
                            spriteBatch.Draw(wallTexture, new Rectangle(wallX, wallY, wallWidth, wallHeight), Color.White);
                        }
                        else
                        {
                            spriteBatch.Draw(wallTexture, new Rectangle(wallX, wallY, wallWidth, wallHeight), fogColor);
                        }
                    }
                }
            }
            spriteBatch.DrawString(gameFont, "LVL:" + Szint.number, new Vector2(0, 10), Color.DarkSeaGreen);
            spriteBatch.DrawString(gameFont, "Curretn HP: " + player.CurrentHP.ToString(), new Vector2(0, 50), Color.Green);
            spriteBatch.DrawString(gameFont, "Max HP:" + player.MaxHP.ToString(), new Vector2(0, 80), Color.DarkOliveGreen);
            spriteBatch.DrawString(gameFont, "Attack:" + player.AttackPoint, new Vector2(0, 110), Color.DarkSeaGreen);
            spriteBatch.DrawString(gameFont, "Deffense: " + player.DefensePoint.ToString(), new Vector2(0, 140), Color.DarkBlue);
            spriteBatch.DrawString(gameFont, "hero LVL:" + player.Level.ToString(), new Vector2(0, 170), Color.Green);
            spriteBatch.DrawString(gameFont, "Have key:" + player.HaveKey, new Vector2(0, 220), Color.Yellow);
            spriteBatch.DrawString(gameFont, "Defeated Boss:" + player.DefeatedBoss, new Vector2(0, 240), Color.DarkSeaGreen);

            float egymonster = 50;
            foreach (var monster in Szint.MonsterList)
            {
                if (monster.GetType().Name != "Boss")
                {
                    spriteBatch.Draw(monster.Texture, new Vector2(820, egymonster), Color.White);
                    egymonster += 40;
                    spriteBatch.DrawString(gameFont, "HP:" + monster.CurrentHP, new Vector2(820, egymonster), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "LVL:" + monster.Level, new Vector2(920, egymonster), Color.DarkRed);
                    egymonster += 30;
                    spriteBatch.DrawString(gameFont, "Attack:" + monster.AttackPoint, new Vector2(820, egymonster), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "DP:" + monster.DefensePoint, new Vector2(920, egymonster), Color.DarkRed);
                    egymonster += 50;
                }
                else
                {
                    spriteBatch.Draw(monster.Texture, new Vector2(0, 290), Color.White);
                    spriteBatch.DrawString(gameFont, "BOSS", new Vector2(0, 330), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "HP: " + monster.CurrentHP, new Vector2(0, 360), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "Attack: " + monster.AttackPoint, new Vector2(0, 390), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "DP: " + monster.DefensePoint, new Vector2(0, 420), Color.DarkRed);
                    spriteBatch.DrawString(gameFont, "LVL: " + monster.Level, new Vector2(0, 450), Color.DarkRed);
                    egymonster += 50;
                }
            }

                        // Kirajzoljuk az animált sprite-ot
            //_spriteBatch.Begin();
            //_spriteBatch.Draw(_animatedSprite, Vector2.Zero, Color.White);
            //_spriteBatch.End();
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
