﻿
using var game = new probgame.Game1();
game.Run();
